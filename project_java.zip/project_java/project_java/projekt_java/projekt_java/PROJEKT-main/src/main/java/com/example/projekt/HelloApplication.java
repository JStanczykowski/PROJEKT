package com.example.projekt;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;

import static javafx.fxml.FXMLLoader.load;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = load(getClass().getResource("login.fxml"));
        stage.setTitle("Hello!");
        stage.setScene(new Scene(root, 1920,1080));
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}