package com.example.projekt;

import eu.hansolo.tilesfx.tools.Point;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.*;
import javafx.scene.paint.Color;

import java.net.URL;
import java.util.ResourceBundle;

import static com.example.projekt.DBUtils.changeScene;
import static com.example.projekt.DBUtils.logInUser;

public class LoginController implements Initializable {

    @FXML
    private Button button_login;
    @FXML
    private TextField dawid;
    @FXML
    private PasswordField dre;
    @FXML
    private Label tekst;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        button_login.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                DBUtils.logInUser(event,dawid.getText(), dre.getText());

            }
        });
    }
    public void setUserInformation(){
        System.out.println("dziala");
    }
    public void przesun(MouseEvent mouseEvent) {

    }
    public void przeciag(DragEvent dragEvent) {



    }

    public void det(MouseEvent mouseEvent) {
        Dragboard db = tekst.startDragAndDrop(TransferMode.ANY);
        ClipboardContent content = new ClipboardContent();
        content.putString("Sdsaasd");
        db.setContent(content);
        mouseEvent.consume();
    }
}
