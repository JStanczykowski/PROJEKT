package com.example.projekt;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

import java.net.URL;
import java.util.ResourceBundle;



public class HelloController implements Initializable {
    @FXML
    private Text tekst;
    @FXML
    private Text tekst1;
    @FXML
    private Button gra;
    @FXML
    private AnchorPane dragi;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        tekst.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                String zmiana = tekst.getText();
                tekst1.setText(zmiana);
            }
        });

    }


    public void przeciag(DragEvent dragEvent) {
        dragEvent.acceptTransferModes(TransferMode.COPY_OR_MOVE);
        System.out.println("Adsasdadad");
        double curr = dragEvent.getX();
        tekst.translateXProperty();
        dragEvent.consume();
    }

    public void przesun(MouseEvent mouseEvent) {
        Dragboard db = tekst.startDragAndDrop(TransferMode.COPY_OR_MOVE);
        ClipboardContent content = new ClipboardContent();
        content.putString("Sdsaasd");
        db.setContent(content);
        mouseEvent.consume();
    }
}
